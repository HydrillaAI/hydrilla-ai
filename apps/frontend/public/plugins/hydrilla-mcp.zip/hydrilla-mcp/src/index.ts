#!/usr/bin/env node
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { PostHog, instrument } from "@posthog/mcp";
import { z } from "zod";
import { CREATE_TIMEOUT_MS, type Task, api, getTask, waitForTask } from "./api.js";
import { APPS, type App, appName, listListeningApps, sendMeshToApp } from "./bridge.js";
import { SERVER_VERSION, getPostHogHost, getPostHogProjectToken, loadLocalEnv } from "./config.js";

loadLocalEnv();

/** How long a generate call waits before handing back the task id to check later. */
const MAX_WAIT_MS = 8 * 60_000;

type ToolResult = {
  content: Array<{ type: "text"; text: string }>;
  isError?: boolean;
};

/** What a tool handler is given besides its arguments; only the parts used here. */
type ToolExtra = {
  _meta?: { progressToken?: string | number };
  sendNotification: (notification: {
    method: "notifications/progress";
    params: { progressToken: string | number; progress: number; total: number; message?: string };
  }) => Promise<void>;
};

const jsonResult = (value: unknown): ToolResult => ({
  content: [{ type: "text", text: JSON.stringify(value, null, 2) }],
});

const errorResult = (error: unknown): ToolResult => ({
  content: [{ type: "text", text: error instanceof Error ? error.message : String(error) }],
  isError: true,
});

/** Run a tool body and turn any failure into a readable tool error. */
const guarded = async (work: () => Promise<ToolResult>): Promise<ToolResult> => {
  try {
    return await work();
  } catch (error) {
    return errorResult(error);
  }
};

/** Progress keeps long generations from hitting the client's request timeout. */
const progressReporter = (extra: ToolExtra) => async (task: Task): Promise<void> => {
  const progressToken = extra._meta?.progressToken;
  if (progressToken === undefined) {
    return;
  }
  try {
    await extra.sendNotification({
      method: "notifications/progress",
      params: {
        progressToken,
        progress: Math.max(0, Math.min(99, Math.round(task.progress ?? 0))),
        total: 100,
        message: task.status_message || (task.status === "PENDING" ? "Waiting for a GPU" : "Generating"),
      },
    });
  } catch {
    // Progress is a courtesy; the tool result still arrives without it.
  }
};

const meshUrlOf = (task: Task): string => task.result?.mesh_url || "";

type Delivery = { sent_to?: string; send_error?: string };

/** Send a finished model to an app, reporting a failure without losing the result. */
const deliver = async (task: Task, app: App | undefined, name: string | undefined): Promise<Delivery> => {
  if (!app) {
    return {};
  }
  try {
    await sendMeshToApp(app, { meshUrl: meshUrlOf(task), name, taskId: task.id });
    return { sent_to: appName(app) };
  } catch (error) {
    return { send_error: error instanceof Error ? error.message : String(error) };
  }
};

/** Wait for a created task and, if asked, place the model in the user's open app. */
const finishGeneration = async (
  taskId: string,
  options: { wait: boolean; sendTo?: App; name?: string },
  extra: ToolExtra
): Promise<ToolResult> => {
  if (!options.wait) {
    return jsonResult({
      id: taskId,
      status: "PENDING",
      note: "Generation started. Check it with hydrilla_get_task; send it to an app with hydrilla_send_to_app once it has succeeded.",
    });
  }
  const { task, timedOut } = await waitForTask(taskId, MAX_WAIT_MS, progressReporter(extra));
  if (timedOut) {
    return jsonResult({
      ...task,
      id: taskId,
      note: "Still generating. Call hydrilla_get_task with this id in a minute; do not start the generation again.",
    });
  }
  if (task.status !== "SUCCEEDED") {
    return errorResult(new Error(task.error || `Generation ${task.status.toLowerCase()}.`));
  }
  const delivery = await deliver({ ...task, id: taskId }, options.sendTo, options.name);
  return jsonResult({ ...task, id: taskId, ...delivery });
};

const server = new McpServer({
  name: "hydrilla",
  version: SERVER_VERSION,
});

const posthogToken = getPostHogProjectToken();
const posthog = posthogToken
  ? new PostHog(posthogToken, {
      host: getPostHogHost(),
      // Stdio processes exit quickly; flush aggressively so tool-call events land.
      flushAt: 1,
      flushInterval: 0,
    })
  : null;

if (posthog) {
  instrument(server, posthog, {
    // Stdio must not write analytics warnings to stdout (corrupts MCP framing).
    logger: (message) => {
      process.stderr.write(`[posthog-mcp] ${message}\n`);
    },
  });
}

const shutdownPostHog = async (): Promise<void> => {
  if (!posthog) {
    return;
  }
  try {
    await posthog.shutdown();
  } catch {
    // Analytics must never break the MCP process.
  }
};

const exitAfterFlush = async (): Promise<void> => {
  await shutdownPostHog();
  process.exit(0);
};

process.once("SIGTERM", () => {
  void exitAfterFlush();
});

process.once("SIGINT", () => {
  void exitAfterFlush();
});

const sendToSchema = z
  .enum(APPS)
  .optional()
  .describe(
    "Put the finished model straight into this open app (the app's Hydrilla plugin must have its Bridge running). Use when the user asks for the model in their scene or project."
  );

const nameSchema = z
  .string()
  .max(48)
  .optional()
  .describe("Short name for the imported object, e.g. 'treasure-chest'");

server.tool(
  "hydrilla_me",
  "Return the Hydrilla account plan and credit balance. Free; use it to check the connection.",
  {},
  async () => guarded(async () => jsonResult(await api<Record<string, unknown>>("/v1/user/me")))
);

server.tool(
  "hydrilla_text_to_3d",
  "Generate a textured 3D model (GLB) from a text prompt. Costs credits and takes a few minutes. Set send_to to place it in the user's open Blender, Unity, Unreal, Godot, Maya or 3ds Max.",
  {
    prompt: z.string().min(1).describe("What to generate"),
    wait: z.boolean().optional().describe("Wait until the model is ready (default true)"),
    send_to: sendToSchema,
    name: nameSchema,
  },
  async ({ prompt, wait = true, send_to, name }, extra) =>
    guarded(async () => {
      const created = await api<{ id: string }>(
        "/v1/3d/text-to-3d",
        { method: "POST", body: JSON.stringify({ prompt }) },
        CREATE_TIMEOUT_MS
      );
      return finishGeneration(created.id, { wait, sendTo: send_to, name }, extra as ToolExtra);
    })
);

server.tool(
  "hydrilla_image_to_3d",
  "Generate a textured 3D model (GLB) from a public image URL. Costs credits and takes a few minutes. Set send_to to place it in the user's open app.",
  {
    image_url: z.string().url().describe("Public image URL"),
    wait: z.boolean().optional().describe("Wait until the model is ready (default true)"),
    send_to: sendToSchema,
    name: nameSchema,
  },
  async ({ image_url, wait = true, send_to, name }, extra) =>
    guarded(async () => {
      const created = await api<{ id: string }>(
        "/v1/3d/image-to-3d",
        { method: "POST", body: JSON.stringify({ image_url }) },
        CREATE_TIMEOUT_MS
      );
      return finishGeneration(created.id, { wait, sendTo: send_to, name }, extra as ToolExtra);
    })
);

server.tool(
  "hydrilla_get_task",
  "Check a Hydrilla 3D task by id. Returns its status and, once it has succeeded, the mesh URL.",
  {
    task_id: z.string().min(1),
  },
  async ({ task_id }) => guarded(async () => jsonResult(await getTask(task_id)))
);

server.tool(
  "hydrilla_list_tasks",
  "List the user's recent Hydrilla 3D models, newest first. Free. Use it to find a model that already exists instead of generating it again.",
  {
    limit: z.number().int().min(1).max(100).optional().describe("How many to return (default 20)"),
  },
  async ({ limit = 20 }) =>
    guarded(async () => jsonResult(await api<Record<string, unknown>>(`/v1/3d/tasks?limit=${limit}`)))
);

server.tool(
  "hydrilla_cancel_task",
  "Stop a Hydrilla 3D task that is still generating. Unused credits are refunded.",
  {
    task_id: z.string().min(1),
  },
  async ({ task_id }) =>
    guarded(async () =>
      jsonResult(
        await api<Record<string, unknown>>(`/v1/3d/tasks/${encodeURIComponent(task_id)}`, { method: "DELETE" })
      )
    )
);

server.tool(
  "hydrilla_list_apps",
  "List which of the user's apps (Blender, Maya, 3ds Max, Unreal, Unity, Godot) are open with the Hydrilla Bridge running and can receive a model right now. Free.",
  {},
  async () =>
    guarded(async () => {
      const listening = await listListeningApps();
      return jsonResult({
        ready: listening,
        note:
          listening.length > 0
            ? "Pass one of these as send_to, or use hydrilla_send_to_app."
            : "No app is listening. Ask the user to open the Hydrilla plugin in their app and click Run Bridge.",
      });
    })
);

server.tool(
  "hydrilla_send_to_app",
  "Put an already generated model into the user's open app (Blender, Unity, Unreal, Godot, Maya or 3ds Max). Free; does not generate anything.",
  {
    app: z.enum(APPS).describe("Which app to send the model to"),
    task_id: z.string().min(1).describe("Id of a task that has succeeded"),
    name: nameSchema,
  },
  async ({ app, task_id, name }) =>
    guarded(async () => {
      const task = await getTask(task_id);
      if (task.status !== "SUCCEEDED" || !meshUrlOf(task)) {
        return errorResult(
          new Error(`Task ${task_id} is ${task.status}, so there is no model to send yet. Check it with hydrilla_get_task.`)
        );
      }
      await sendMeshToApp(app, { meshUrl: meshUrlOf(task), name, taskId: task_id });
      return jsonResult({ id: task_id, sent_to: appName(app) });
    })
);

const transport = new StdioServerTransport();
await server.connect(transport);

process.once("beforeExit", () => {
  void shutdownPostHog();
});
